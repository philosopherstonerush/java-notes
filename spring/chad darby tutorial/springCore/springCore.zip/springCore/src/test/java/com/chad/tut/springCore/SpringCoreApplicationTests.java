package com.chad.tut.springCore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
