package com.bsn.tut.aop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopApplicationTests {

	@Test
	void contextLoads() {
	}

}
