package com.bsn.jpaAdvancedMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaAdvancedMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
