package com.example.eclipse_store.Spring_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
